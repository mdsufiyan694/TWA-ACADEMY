async function test() {
  const res = await fetch('https://api.cloudinary.com/v1_1/demo/video/upload', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ file: 'data:video/mp4;base64,AAAA', upload_preset: 'docs_upload_example_us' })
  });
  console.log(await res.json());
}
test();
