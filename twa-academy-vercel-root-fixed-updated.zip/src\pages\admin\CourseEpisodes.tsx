import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, Reorder } from 'motion/react';
import { Plus, GripVertical, ExternalLink, ArrowLeft, Loader2, PlayCircle, X } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { CustomVideoPlayer } from '../../components/ui/CustomVideoPlayer';
import { AdminUpload } from '../../components/AdminUpload';

import localforage from 'localforage';

export function CourseEpisodes() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { courses, addEpisode, updateCourse } = useApp();
  
  const course = courses.find(c => c.id === id);
  const [episodes, setEpisodes] = useState(course?.episodes.sort((a,b) => a.order - b.order) || []);
  
  useEffect(() => {
    if (course) {
      setEpisodes(course.episodes.sort((a,b) => a.order - b.order));
    }
  }, [course]);
  
  const [isAdding, setIsAdding] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [previewVideoUrl, setPreviewVideoUrl] = useState<string | null>(null);

  if (!course) return <div>Course not found</div>;

  const handleSaveUpload = async (data: { title: string; description: string; file: File; url: string; duration: string }) => {
    setIsUploading(true);
    setUploadProgress(0);

    // Fast local upload using IndexedDB
    const progressInterval = setInterval(() => {
      setUploadProgress(p => p >= 90 ? 90 : p + 15);
    }, 100);

    try {
      const dbKey = `video_${Date.now()}`;
      await localforage.setItem(dbKey, data.file);
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      // Artificial slight delay for UX
      await new Promise(r => setTimeout(r, 400));
      
      await addEpisode(course.id, {
        title: data.title,
        description: data.description,
        videoUrl: `localdb://${dbKey}`,
        duration: data.duration,
        order: episodes.length + 1
      });
    } catch (e) {
      console.error(e);
      alert('Local upload failed. Storage might be full.');
    } finally {
      setIsAdding(false);
      setIsUploading(false);
      clearInterval(progressInterval);
    }
  };

  const onReorder = (newOrder: typeof episodes) => {
    setEpisodes(newOrder);
    updateCourse(course.id, { episodes: newOrder.map((e, i) => ({ ...e, order: i + 1 })) });
  };

  const openPreview = async (videoUrl: string) => {
    if (videoUrl.startsWith('localdb://')) {
      const key = videoUrl.replace('localdb://', '');
      try {
        const blob = await localforage.getItem<Blob>(key);
        if (blob) {
          setPreviewVideoUrl(URL.createObjectURL(blob));
        } else {
          alert('Video file not found in local storage.');
        }
      } catch (err) {
        console.error("Local video fetch failed:", err);
        alert('Failed to load video from local storage.');
      }
    } else {
      setPreviewVideoUrl(videoUrl);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-4 mb-2">
        <button onClick={() => navigate('/admin/courses')} className="text-gray-400 hover:text-white">
          <ArrowLeft size={24} />
        </button>
        <div>
          <h1 className="text-2xl font-bold">{course.title} - Videos</h1>
          <p className="text-gray-400 text-sm">Manage curriculum and video lessons</p>
        </div>
      </div>

      <div className="flex justify-end">
         <Button onClick={() => setIsAdding(!isAdding)}>
           <Plus size={18} className="mr-2" /> Add Video Lesson
         </Button>
      </div>

      {isAdding && !isUploading && (
        <AdminUpload 
          onSave={handleSaveUpload} 
          onCancel={() => setIsAdding(false)} 
        />
      )}

      {isUploading && (
        <GlassCard className="p-8 text-center flex flex-col items-center justify-center space-y-4">
          <Loader2 size={48} className="text-primary animate-spin" />
          <div>
            <h3 className="font-semibold text-lg">Uploading Video...</h3>
            <p className="text-sm text-gray-400">Please do not close this window.</p>
          </div>
          <div className="w-full max-w-md bg-black rounded-full h-3 overflow-hidden border border-white/10 mt-4">
            <div 
              className="bg-primary h-full transition-all duration-300"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
          <p className="text-xs text-primary font-mono mt-2">{Math.round(uploadProgress)}%</p>
        </GlassCard>
      )}

      {episodes.length === 0 && !isAdding && !isUploading && (
        <div className="text-center py-20 bg-white/5 border border-white/10 rounded-2xl border-dashed">
          <p className="text-gray-400">No videos added to this course yet.</p>
        </div>
      )}

      <Reorder.Group axis="y" values={episodes} onReorder={onReorder} className="space-y-3">
        {episodes.map((ep, i) => (
          <Reorder.Item key={ep.id} value={ep} className="relative z-10">
            <GlassCard className="p-4 flex items-center gap-4 cursor-grab active:cursor-grabbing hover:bg-white/10 transition-colors">
              <GripVertical className="text-gray-500" size={20} />
              <div className="w-8 h-8 rounded bg-primary/10 text-primary flex items-center justify-center font-bold text-sm">
                {i + 1}
              </div>
              <div className="flex-1">
                <h4 className="font-semibold">{ep.title}</h4>
                <div className="text-xs text-gray-400 flex items-center gap-2 mt-1">
                  <span>{ep.duration}</span>
                  <button 
                    onClick={() => openPreview(ep.videoUrl)}
                    className="flex items-center gap-1 text-primary hover:text-white transition-colors"
                  >
                    <PlayCircle size={14} /> Play
                  </button>
                </div>
              </div>
              <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-400 hover:bg-red-500/10">Remove</Button>
            </GlassCard>
          </Reorder.Item>
        ))}
      </Reorder.Group>

      {previewVideoUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95">
          <div className="relative w-full max-w-5xl aspect-video">
            <button 
              onClick={() => setPreviewVideoUrl(null)}
              className="absolute -top-12 right-0 p-2 text-white hover:text-red-500 transition-colors z-50 bg-white/10 rounded-full"
            >
              <X size={24} />
            </button>
            <CustomVideoPlayer 
              src={previewVideoUrl} 
              className="w-full h-full bg-black shadow-2xl rounded-lg border border-white/10"
            />
          </div>
        </div>
      )}
    </div>
  );
}
