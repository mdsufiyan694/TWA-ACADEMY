import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthenticateWithRedirectCallback } from '@clerk/clerk-react';
import { MainLayout } from '../components/layout/MainLayout';
import { DashboardLayout } from '../components/layout/DashboardLayout';

// Pages
import { Home } from '../pages/Home';
import { Courses } from '../pages/Courses';
import { StudentLogin } from '../pages/StudentLogin';
import { AdminLogin } from '../pages/AdminLogin';

// Admin
import { AdminDashboard } from '../pages/admin/AdminDashboard';
import { AdminCourses } from '../pages/admin/AdminCourses';
import { CourseEpisodes } from '../pages/admin/CourseEpisodes';
import { AdminStudents } from '../pages/admin/AdminStudents';
import { AdminSettings } from '../pages/admin/AdminSettings';

// Student
import { Dashboard } from '../pages/student/Dashboard';
import { VideoPlayer } from '../pages/student/VideoPlayer';
import { MyCourses } from '../pages/student/MyCourses';
import { Profile } from '../pages/student/Profile';

export function AppRoutes() {
  return (
    <Routes>
      {/* Public Routes with Navbar/Footer */}
      <Route element={<MainLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/courses" element={<Courses />} />
        {/* Make courses slug preview also show public or redirect to login. For simplicity, just courses grid is public */}
      </Route>

      {/* Auth */}
      <Route path="/login" element={<StudentLogin />} />
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/sso-callback" element={<AuthenticateWithRedirectCallback />} />

      {/* Legacy auth route redirect */}
      <Route path="/auth/signin" element={<Navigate to="/login" replace />} />

      {/* Admin Protected Routes */}
      <Route element={<DashboardLayout requiredRole="ADMIN" />}>
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/courses" element={<AdminCourses />} />
        <Route path="/admin/courses/:id/episodes" element={<CourseEpisodes />} />
        <Route path="/admin/students" element={<AdminStudents />} />
        <Route path="/admin/settings" element={<AdminSettings />} />
      </Route>

      {/* Student Protected Routes */}
      <Route element={<DashboardLayout requiredRole="STUDENT" />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/dashboard/courses" element={<MyCourses />} />
        <Route path="/dashboard/courses/:slug" element={<VideoPlayer />} />
        <Route path="/dashboard/courses/:slug/:episodeId" element={<VideoPlayer />} />
        <Route path="/dashboard/profile" element={<Profile />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
