import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Ban, CheckCircle2, ArrowLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Link } from 'react-router-dom';

export function AdminStudents() {
  const { allUsers, toggleUserBlock } = useApp();
  const [searchTerm, setSearchTerm] = useState('');

  const students = allUsers.filter(u => u.role === 'STUDENT' && (u.name.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase())));

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center bg-bg-sec p-6 rounded-2xl border border-white/10 sticky top-0 z-10 gap-4">
        <div className="flex items-center gap-3">
          <Link
            to="/admin"
            className="inline-flex items-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
            title="Back to Dashboard"
          >
            <ArrowLeft size={24} />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Manage Students</h1>
            <p className="text-gray-400 text-sm">View student progress and manage access</p>
          </div>
        </div>
        <div>
          <input 
            type="text" 
            placeholder="Search name or email..." 
            className="bg-bg-main border border-white/10 rounded-lg px-4 py-2 w-full md:w-64"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <GlassCard className="p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white/5 border-b border-white/10">
                <th className="p-4 font-medium text-gray-400 text-sm">Student</th>
                <th className="p-4 font-medium text-gray-400 text-sm">Joined Date</th>
                <th className="p-4 font-medium text-gray-400 text-sm">Status</th>
                <th className="p-4 font-medium text-gray-400 text-sm text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {students.map((student) => (
                <tr key={student.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-main flex items-center justify-center text-white font-bold">
                        {student.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-xs text-gray-400">{student.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-sm text-gray-300">
                    {new Date(student.createdAt).toLocaleDateString()}
                  </td>
                  <td className="p-4">
                    <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${student.isBlocked ? 'bg-red-500/10 text-red-500' : 'bg-green-500/10 text-green-500'}`}>
                      {student.isBlocked ? <><Ban size={12}/> Blocked</> : <><CheckCircle2 size={12}/> Active</>}
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => toggleUserBlock(student.id)}
                      className={student.isBlocked ? 'text-green-500 hover:text-green-400 hover:bg-green-500/10' : 'text-red-500 hover:text-red-400 hover:bg-red-500/10'}
                    >
                      {student.isBlocked ? 'Unblock' : 'Block Access'}
                    </Button>
                  </td>
                </tr>
              ))}
              {students.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-gray-400">
                    No students found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}
