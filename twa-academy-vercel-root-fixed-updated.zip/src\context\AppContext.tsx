import React, { createContext, useContext, useState, useEffect } from 'react';
import { useClerk, useUser } from '@clerk/clerk-react';
import type { User, Course, Progress, Episode } from '../types';
import { localBackend } from '../lib/localBackend';

interface LoginOptions {
  name?: string;
  email: string;
  password: string;
  mode?: 'login' | 'signup';
}

interface AppContextType {
  user: User | null;
  courses: Course[];
  progress: Progress[];
  allUsers: User[];
  isLoadingAuth: boolean;
  isLoadingData: boolean;
  setLocalAdminSession: (email: string) => void;
  login: (role: 'ADMIN' | 'STUDENT', options?: LoginOptions) => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  signupWithEmail: (name: string, email: string, password: string, role: 'ADMIN' | 'STUDENT') => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  addCourse: (course: Partial<Course>) => Promise<void>;
  updateCourse: (id: string, course: Partial<Course>) => Promise<void>;
  deleteCourse: (id: string) => Promise<void>;
  addEpisode: (courseId: string, episode: Partial<Episode>) => Promise<void>;
  markEpisodeComplete: (courseId: string, episodeId: string) => Promise<void>;
  toggleUserBlock: (userId: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const { user: clerkUser, isLoaded: isClerkLoaded, isSignedIn } = useUser();
  const { signOut } = useClerk();

  useEffect(() => {
    const unsubscribe = localBackend.subscribe((db) => {
      setCourses(db.courses);
      setProgress(db.progress);
      setAllUsers(db.users);
      setIsLoadingData(false);
    });

    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!isClerkLoaded) return;

    try {
      const localUser = localBackend.getCurrentUser();

      // Admin login stays fully separate from Clerk/Google login.
      if (localUser?.role === 'ADMIN') {
        setUser(localUser);
        setIsLoadingAuth(false);
        return;
      }

      if (isSignedIn && clerkUser) {
        const primaryEmail = clerkUser.primaryEmailAddress?.emailAddress || clerkUser.emailAddresses[0]?.emailAddress || '';
        const studentUser = localBackend.upsertGoogleStudent({
          clerkId: clerkUser.id,
          name: clerkUser.fullName || clerkUser.username || primaryEmail.split('@')[0] || 'Student',
          email: primaryEmail,
          photo: clerkUser.imageUrl,
        });
        setUser(studentUser);
        setIsLoadingAuth(false);
        return;
      }

      // Student sessions must come from Clerk. Clear old local student sessions after Firebase removal.
      if (localUser?.role === 'STUDENT') {
        localBackend.logout();
      }
      setUser(null);
      setIsLoadingAuth(false);
    } catch (error) {
      console.error('Authentication sync failed:', error);
      setUser(null);
      setIsLoadingAuth(false);
    }
  }, [isClerkLoaded, isSignedIn, clerkUser?.id]);

  const setLocalAdminSession = (email: string) => {
    const adminUser = localBackend.setAdminSession(email);
    setUser(adminUser);
  };

  const login = async (role: 'ADMIN' | 'STUDENT', options?: LoginOptions) => {
    if (role === 'ADMIN') {
      throw new Error('Please use the admin login form.');
    }

    if (!options?.email || !options?.password) {
      throw new Error('Student login now uses Google authentication. Please click Continue with Google.');
    }

    const loggedInUser = options.mode === 'signup'
      ? await localBackend.studentSignup(options.name || '', options.email, options.password)
      : await localBackend.studentLogin(options.email, options.password);

    setUser(loggedInUser);
  };

  const loginWithEmail = async (email: string, password: string) => {
    if (email === 'twaacademy@gmail.com' && password === 'TWA@0102') {
      setLocalAdminSession(email);
      return;
    }
    throw new Error('Invalid admin email or password.');
  };

  const signupWithEmail = async (name: string, email: string, password: string, role: 'ADMIN' | 'STUDENT') => {
    if (role === 'ADMIN') {
      throw new Error('Admin signup is disabled. Use the existing admin account.');
    }
    const newUser = await localBackend.studentSignup(name, email, password);
    setUser(newUser);
  };

  const resetPassword = async (_email: string) => {
    throw new Error('Password reset is not available. Student login now uses Google authentication.');
  };

  const logout = async () => {
    const currentUser = user;
    localBackend.logout();
    setUser(null);

    if (currentUser?.role === 'STUDENT' && isSignedIn) {
      await signOut({ redirectUrl: '/login' });
    }
  };

  const addCourse = async (course: Partial<Course>) => {
    localBackend.addCourse(course);
  };

  const updateCourse = async (id: string, updates: Partial<Course>) => {
    localBackend.updateCourse(id, updates);
  };

  const deleteCourse = async (id: string) => {
    localBackend.deleteCourse(id);
  };

  const addEpisode = async (courseId: string, episode: Partial<Episode>) => {
    localBackend.addEpisode(courseId, episode);
  };

  const markEpisodeComplete = async (courseId: string, episodeId: string) => {
    if (!user) return;
    localBackend.markEpisodeComplete(user.id, courseId, episodeId);
  };

  const toggleUserBlock = async (userId: string) => {
    localBackend.toggleUserBlock(userId);
  };

  return (
    <AppContext.Provider value={{
      user, courses, progress, allUsers, isLoadingAuth, isLoadingData,
      setLocalAdminSession, login, loginWithEmail, signupWithEmail, resetPassword, logout,
      addCourse, updateCourse, deleteCourse, addEpisode, markEpisodeComplete, toggleUserBlock
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
