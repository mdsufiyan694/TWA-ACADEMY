import React from 'react';
import { ArrowLeft, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

export function Profile() {
  const { user } = useApp();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 bg-bg-sec p-6 rounded-2xl border border-white/10 sticky top-0 z-10">
        <Link
          to="/dashboard"
          className="inline-flex items-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
          title="Back to Dashboard"
        >
          <ArrowLeft size={24} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">Profile</h1>
          <p className="text-gray-400 text-sm">Manage your personal information</p>
        </div>
      </div>

      <div className="bg-bg-sec border border-white/10 rounded-2xl p-6">
        <div className="flex items-center gap-6 mb-8">
          <div className="w-24 h-24 rounded-full bg-gradient-main flex items-center justify-center text-4xl text-white font-bold">
            {user?.name?.charAt(0)?.toUpperCase()}
          </div>
          <div>
            <h2 className="text-2xl font-semibold">{user?.name}</h2>
            <p className="text-gray-400">{user?.email}</p>
            <span className="inline-block px-3 py-1 bg-white/10 rounded-full text-sm mt-2">
              Student Account
            </span>
          </div>
        </div>

        <div className="text-gray-400 border-t border-white/10 pt-6">
          <p>Additional profile settings coming soon.</p>
        </div>
      </div>
    </div>
  );
}
