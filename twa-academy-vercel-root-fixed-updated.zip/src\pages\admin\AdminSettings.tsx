import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export function AdminSettings() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center bg-bg-sec p-6 rounded-2xl border border-white/10 sticky top-0 z-10 gap-4">
        <div className="flex items-center gap-3">
          <Link
            to="/admin"
            className="inline-flex items-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
            title="Back to Dashboard"
          >
            <ArrowLeft size={24} />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Platform Settings</h1>
            <p className="text-gray-400 text-sm">Manage configuration and preferences</p>
          </div>
        </div>
      </div>
      <div className="p-8 text-center text-gray-400 border border-white/10 rounded-2xl border-dashed">
        Platform Settings Coming Soon
      </div>
    </div>
  );
}
