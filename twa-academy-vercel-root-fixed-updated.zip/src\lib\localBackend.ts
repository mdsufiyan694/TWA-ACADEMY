import type { Course, Episode, Progress, User } from '../types';

type StoredUser = User & { passwordHash?: string };

type Database = {
  users: StoredUser[];
  courses: Course[];
  progress: Progress[];
};

const DB_KEY = 'twa_academy_local_backend_v1';
const SESSION_KEY = 'twa_academy_session_v1';

const seedCourses: Course[] = [
  {
    id: 'course-beginner-stock-market',
    title: 'Beginner Stock Market Course',
    description: 'Learn stock market basics, trading accounts, candlestick patterns, and technical analysis foundations.',
    category: 'Beginner Trading',
    thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=800&q=80',
    tags: ['Stock Market', 'Candlesticks', 'Technical Analysis'],
    isPublished: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    episodes: [],
  },
];

const defaultDb: Database = {
  users: [],
  courses: seedCourses,
  progress: [],
};

function safeJsonParse<T>(value: string | null, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function readDb(): Database {
  return safeJsonParse<Database>(localStorage.getItem(DB_KEY), defaultDb);
}

function writeDb(db: Database) {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
  window.dispatchEvent(new Event('twa-local-backend-updated'));
}

function sanitizeUser(user: StoredUser): User {
  const { passwordHash: _passwordHash, ...publicUser } = user;
  return publicUser;
}

async function hashPassword(password: string): Promise<string> {
  const data = new TextEncoder().encode(password);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export const localBackend = {
  subscribe(callback: (db: { users: User[]; courses: Course[]; progress: Progress[] }) => void) {
    const emit = () => {
      const db = readDb();
      callback({
        users: db.users.map(sanitizeUser),
        courses: db.courses,
        progress: db.progress,
      });
    };

    emit();
    window.addEventListener('storage', emit);
    window.addEventListener('twa-local-backend-updated', emit);

    return () => {
      window.removeEventListener('storage', emit);
      window.removeEventListener('twa-local-backend-updated', emit);
    };
  },

  getCurrentUser(): User | null {
    const session = safeJsonParse<{ userId?: string; role?: User['role']; email?: string }>(localStorage.getItem(SESSION_KEY), {});
    if (!session.userId) return null;

    if (session.role === 'ADMIN') {
      return {
        id: session.userId,
        name: 'Admin',
        email: session.email || 'twaacademy@gmail.com',
        role: 'ADMIN',
        isBlocked: false,
        createdAt: new Date().toISOString(),
      };
    }

    const db = readDb();
    const storedUser = db.users.find(u => u.id === session.userId);
    if (!storedUser || storedUser.isBlocked) {
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
    return sanitizeUser(storedUser);
  },

  setAdminSession(email: string): User {
    const adminUser: User = {
      id: 'local_admin_session',
      name: 'Admin',
      email,
      role: 'ADMIN',
      isBlocked: false,
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: adminUser.id, role: 'ADMIN', email }));
    localStorage.setItem('adminAuthenticated', 'true');
    localStorage.setItem('adminEmail', email);
    return adminUser;
  },

  async studentLogin(email: string, password: string): Promise<User> {
    const db = readDb();
    const storedUser = db.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase() && u.role === 'STUDENT');
    if (!storedUser) throw new Error('No student account found. Create an account first.');
    if (storedUser.isBlocked) throw new Error('Your account is blocked. Please contact the admin.');

    const passwordHash = await hashPassword(password);
    if (storedUser.passwordHash !== passwordHash) throw new Error('Invalid email or password.');

    localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: storedUser.id, role: 'STUDENT' }));
    return sanitizeUser(storedUser);
  },

  async studentSignup(name: string, email: string, password: string): Promise<User> {
    if (!name.trim()) throw new Error('Please enter your full name.');
    if (!email.trim()) throw new Error('Please enter your email address.');
    if (password.length < 6) throw new Error('Password must be at least 6 characters.');

    const db = readDb();
    const normalizedEmail = email.trim().toLowerCase();
    const alreadyExists = db.users.some(u => u.email.toLowerCase() === normalizedEmail);
    if (alreadyExists) throw new Error('This email is already registered. Please login.');

    const newUser: StoredUser = {
      id: `user-${Date.now()}`,
      name: name.trim(),
      email: normalizedEmail,
      role: 'STUDENT',
      isBlocked: false,
      createdAt: new Date().toISOString(),
      passwordHash: await hashPassword(password),
    };

    db.users.push(newUser);
    writeDb(db);
    localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: newUser.id, role: 'STUDENT' }));
    return sanitizeUser(newUser);
  },


  upsertGoogleStudent(profile: { clerkId: string; name: string; email: string; photo?: string }): User {
    if (!profile.email.trim()) {
      throw new Error('Google account email not found. Please choose another Gmail account.');
    }

    const db = readDb();
    const normalizedEmail = profile.email.trim().toLowerCase();
    const existingIndex = db.users.findIndex(
      u => u.role === 'STUDENT' && (u.googleId === profile.clerkId || u.email.toLowerCase() === normalizedEmail)
    );

    let student: StoredUser;

    if (existingIndex >= 0) {
      student = {
        ...db.users[existingIndex],
        googleId: profile.clerkId,
        name: profile.name.trim() || db.users[existingIndex].name || 'Student',
        email: normalizedEmail,
        photo: profile.photo || db.users[existingIndex].photo,
      };
      db.users[existingIndex] = student;
    } else {
      student = {
        id: `clerk-${profile.clerkId}`,
        googleId: profile.clerkId,
        name: profile.name.trim() || 'Student',
        email: normalizedEmail,
        photo: profile.photo,
        role: 'STUDENT',
        isBlocked: false,
        createdAt: new Date().toISOString(),
      };
      db.users.push(student);
    }

    if (student.isBlocked) {
      localStorage.removeItem(SESSION_KEY);
      throw new Error('Your account is blocked. Please contact the admin.');
    }

    writeDb(db);
    localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: student.id, role: 'STUDENT' }));
    return sanitizeUser(student);
  },

  logout() {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem('adminAuthenticated');
    localStorage.removeItem('adminEmail');
  },

  addCourse(course: Partial<Course>): Course {
    const db = readDb();
    const now = new Date().toISOString();
    const newCourse: Course = {
      id: `course-${Date.now()}`,
      title: course.title || '',
      description: course.description || '',
      category: course.category || '',
      thumbnail: course.thumbnail || '',
      tags: course.tags || [],
      isPublished: !!course.isPublished,
      createdAt: now,
      updatedAt: now,
      episodes: [],
      ...course,
    };
    db.courses.unshift(newCourse);
    writeDb(db);
    return newCourse;
  },

  updateCourse(id: string, updates: Partial<Course>) {
    const db = readDb();
    db.courses = db.courses.map(course => course.id === id ? { ...course, ...updates, updatedAt: new Date().toISOString() } : course);
    writeDb(db);
  },

  deleteCourse(id: string) {
    const db = readDb();
    db.courses = db.courses.filter(course => course.id !== id);
    db.progress = db.progress.filter(item => item.courseId !== id);
    writeDb(db);
  },

  addEpisode(courseId: string, episode: Partial<Episode>) {
    const db = readDb();
    const course = db.courses.find(c => c.id === courseId);
    if (!course) throw new Error('Course not found.');

    const newEpisode: Episode = {
      id: `ep-${Date.now()}`,
      courseId,
      title: episode.title || '',
      description: episode.description || '',
      videoUrl: episode.videoUrl || '',
      duration: episode.duration || '',
      order: episode.order || course.episodes.length + 1,
    };

    course.episodes = [...course.episodes, newEpisode].sort((a, b) => a.order - b.order);
    course.updatedAt = new Date().toISOString();
    writeDb(db);
  },

  markEpisodeComplete(userId: string, courseId: string, episodeId: string) {
    const db = readDb();
    const exists = db.progress.some(p => p.userId === userId && p.episodeId === episodeId);
    if (exists) return;

    db.progress.push({
      id: `prog-${Date.now()}`,
      userId,
      courseId,
      episodeId,
      isCompleted: true,
      watchedAt: new Date().toISOString(),
    });
    writeDb(db);
  },

  toggleUserBlock(userId: string) {
    const db = readDb();
    db.users = db.users.map(u => u.id === userId ? { ...u, isBlocked: !u.isBlocked } : u);
    writeDb(db);
  },
};
