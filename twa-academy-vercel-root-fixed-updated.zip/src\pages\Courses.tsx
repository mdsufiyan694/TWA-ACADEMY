import React from 'react';
import { Link } from 'react-router-dom';
import { Play } from 'lucide-react';
import { GlassCard } from '../components/ui/GlassCard';
import { Button } from '../components/ui/Button';
import { useApp } from '../context/AppContext';
import { motion } from 'motion/react';

export function Courses() {
  const { courses, user } = useApp();
  const publishedCourses = courses.filter(c => c.isPublished);

  return (
    <div className="container mx-auto px-6 max-w-7xl pt-10 pb-24">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16 text-center"
      >
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Premium <span className="text-gradient">Courses</span></h1>
        <p className="text-gray-400 max-w-2xl mx-auto">Enhance your trading skills with our expertly crafted courses. From absolute beginners to advanced options traders.</p>
      </motion.div>

      {publishedCourses.length === 0 ? (
        <div className="text-center text-gray-500 py-20">No courses available yet.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {publishedCourses.map((course, i) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
            >
              <GlassCard hoverEffect className="p-0 overflow-hidden group flex flex-col h-full">
                <div className="h-48 overflow-hidden relative">
                  <img src={course.thumbnail || undefined} alt={course.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute top-4 left-4 bg-primary text-black text-xs font-bold px-3 py-1 rounded-full">
                    {course.category}
                  </div>
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">{course.title}</h3>
                  <p className="text-gray-400 text-sm mb-6 line-clamp-3">{course.description}</p>
                  <div className="mt-auto flex items-center justify-between">
                    <div className="text-sm text-gray-500 flex items-center gap-1">
                      <Play size={14} /> {course.episodes.length} Episodes
                    </div>
                    <Link to={user ? `/dashboard/courses/${course.id}` : "/login"}>
                      <Button variant="outline" size="sm">Learn Now</Button>
                    </Link>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
