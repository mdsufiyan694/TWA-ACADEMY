import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, ArrowRight, Video, CheckCircle, PlayCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Button } from '../../components/ui/Button';
import { GlassCard } from '../../components/ui/GlassCard';
import { CustomVideoPlayer } from '../../components/ui/CustomVideoPlayer';
import localforage from 'localforage';

export function VideoPlayer() {
  const { slug, episodeId } = useParams();
  const navigate = useNavigate();
  const { courses, progress, markEpisodeComplete, user } = useApp();

  const course = courses.find(c => c.id === slug);
  const episodes = [...(course?.episodes || [])].sort((a,b) => a.order - b.order);
  
  // If no episodeId is provided, default to the first one
  const currentEpisodeId = episodeId || (episodes.length > 0 ? episodes[0].id : null);
  const currentEpisode = episodes.find(e => e.id === currentEpisodeId);
  
  const currentIndex = episodes.findIndex(e => e.id === currentEpisodeId);
  const nextEpisode = currentIndex < episodes.length - 1 ? episodes[currentIndex + 1] : null;
  const prevEpisode = currentIndex > 0 ? episodes[currentIndex - 1] : null;

  const [actualVideoUrl, setActualVideoUrl] = useState<string>('');

  useEffect(() => {
    if (currentEpisode) {
      if (currentEpisode.videoUrl.startsWith('localdb://')) {
        const key = currentEpisode.videoUrl.replace('localdb://', '');
        localforage.getItem<Blob>(key).then((blob) => {
          if (blob) {
            setActualVideoUrl(URL.createObjectURL(blob));
          }
        }).catch(err => {
          console.error("Local video fetch failed:", err);
          setActualVideoUrl('');
        });
      } else {
        setActualVideoUrl(currentEpisode.videoUrl);
      }
    }
  }, [currentEpisode]);

  if (!course || !currentEpisode) return <div className="p-8 text-center text-gray-400">Course or Video not found.</div>;

  const isCompleted = progress.some(p => p.userId === user?.id && p.episodeId === currentEpisode.id && p.isCompleted);

  const handleMarkComplete = () => {
    markEpisodeComplete(course.id, currentEpisode.id);
  };

  const handleNext = () => {
    if (nextEpisode) {
      navigate(`/dashboard/courses/${course.id}/${nextEpisode.id}`);
    }
  };

  const handlePrev = () => {
    if (prevEpisode) {
      navigate(`/dashboard/courses/${course.id}/${prevEpisode.id}`);
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 max-w-7xl mx-auto">
      {/* Video Section */}
        <div className="flex-1 space-y-6">
        <div className="flex items-center gap-4 mb-2">
          <button onClick={() => navigate('/dashboard')} className="text-gray-400 hover:text-white transition-colors">
            <ArrowLeft size={24} />
          </button>
          <span className="text-sm font-medium text-gray-400">Back to Dashboard</span>
        </div>
        <GlassCard className="p-0 overflow-hidden bg-black aspect-video relative flex items-center justify-center border-white/10 shadow-2xl">
          <CustomVideoPlayer
            src={actualVideoUrl}
            className="w-full h-full absolute inset-0 bg-black"
          />
        </GlassCard>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold mb-1">{currentEpisode.title}</h1>
            <p className="text-gray-400 text-sm">{course.title} • Module {currentIndex + 1}</p>
          </div>
          <div className="flex items-center gap-3">
             <Button
                variant={isCompleted ? 'outline' : 'primary'}
                className={isCompleted ? 'text-primary border-primary hover:bg-primary/10' : ''}
                onClick={handleMarkComplete}
              >
                {isCompleted ? <><CheckCircle size={18} className="mr-2" /> Completed</> : 'Mark as Complete'}
              </Button>
          </div>
        </div>

        <GlassCard>
          <h3 className="font-semibold mb-2 text-lg">About this lesson</h3>
          <p className="text-gray-400 leading-relaxed text-sm">
            {currentEpisode.description || 'No description provided for this lesson.'}
          </p>
        </GlassCard>
      </div>

      {/* Playlist Sidebar */}
      <div className="w-full lg:w-80 flex-shrink-0 space-y-4">
        <div className="bg-bg-sec border border-white/10 rounded-xl h-full max-h-[80vh] flex flex-col overflow-hidden">
          <div className="p-4 border-b border-white/10 shrink-0">
            <h2 className="font-bold">Course Curriculum</h2>
            <p className="text-xs text-text-secondary">{course.title}</p>
          </div>
          <div className="flex-1 overflow-y-auto">
            {episodes.map((ep, i) => {
              const isEpiCompleted = progress.some(p => p.userId === user?.id && p.episodeId === ep.id && p.isCompleted);
              const isActive = ep.id === currentEpisode.id;

              return (
                <div 
                  key={ep.id}
                  onClick={() => navigate(`/dashboard/courses/${course.id}/${ep.id}`)}
                  className={`flex gap-3 p-4 cursor-pointer transition-colors border-b border-white/5 ${
                    isActive 
                      ? 'bg-primary/10 border-l-4 border-l-primary' 
                      : 'hover:bg-white/5 opacity-80 border-l-0'
                  }`}
                >
                  <div className="w-16 h-10 rounded bg-white/10 shrink-0 flex items-center justify-center mt-1">
                    {isEpiCompleted ? (
                      <CheckCircle size={16} className="text-primary" />
                    ) : (
                      <PlayCircle size={16} className={isActive ? 'text-primary' : 'text-white/40'} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs font-bold leading-tight line-clamp-2`}>
                      {i + 1}. {ep.title}
                    </p>
                    <p className="text-[10px] text-text-secondary mt-1">{ep.duration} mins</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Navigation Controls */}
           <div className="p-4 border-t border-white/10 mt-auto flex items-center justify-between shrink-0">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handlePrev} 
                disabled={!prevEpisode}
                className="px-4 py-2 border-white/20 text-xs text-white bg-transparent"
              >
                <ArrowLeft size={14} className="mr-1" /> Prev
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleNext} 
                disabled={!nextEpisode}
                className="px-4 py-2 border-white/20 text-xs text-white bg-transparent"
              >
                Next <ArrowRight size={14} className="ml-1" />
              </Button>
           </div>
        </div>
      </div>
    </div>
  );
}
