import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar';

export function MainLayout() {
  return (
    <div className="page-wrapper flex flex-col w-full">
      <Navbar />
      <main className="flex-grow pt-20">
        <Outlet />
      </main>
      <footer className="border-t border-white/10 py-12 bg-bg-main mt-20">
        <div className="container mx-auto px-6 max-w-7xl flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-white mb-1">TWA ACADEMY</span>
            <span className="text-sm text-gray-400">Trade Make Simple</span>
          </div>
          <div className="text-sm text-gray-500">
            © {new Date().getFullYear()} TWA Academy. All Rights Reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
