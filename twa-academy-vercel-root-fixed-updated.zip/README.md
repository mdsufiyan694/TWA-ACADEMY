# TWA Academy

Firebase has been removed from this version.

## What changed

- Removed Firebase Google login.
- Removed Firestore and Firebase Storage usage.
- Added a local browser backend using `localStorage` for users/courses/progress.
- Video files are saved in browser IndexedDB using `localforage`.
- Student login now uses email/password with a Create Account form.

## Admin login

Email: `twaacademy@gmail.com`
Password: `TWA@0102`

## Run locally

```bash
npm install
npm run dev
```

Open:

```txt
http://localhost:3000
```

## Build

```bash
npm run build
```

## Important production note

This local backend is best for demo/testing because data is stored in the visitor's browser. For a real production course website, connect Supabase, Appwrite, Clerk, or a Node.js + MongoDB backend.
