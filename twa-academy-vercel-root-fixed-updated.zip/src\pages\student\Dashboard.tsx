import React from 'react';
import { motion } from 'motion/react';
import { PlayCircle, Clock, BookOpen, CheckCircle, ArrowLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GlassCard } from '../../components/ui/GlassCard';
import { Link } from 'react-router-dom';
import { Button } from '../../components/ui/Button';

export function Dashboard() {
  const { user, courses, progress, isLoadingData } = useApp();
  const publishedCourses = courses.filter(c => c.isPublished);

  const completedEpisodes = progress.filter(p => p.userId === user?.id && p.isCompleted).length;
  
  const stats = [
    { label: 'Courses Enrolled', value: publishedCourses.length, icon: BookOpen },
    { label: 'Videos Completed', value: completedEpisodes, icon: CheckCircle },
    { label: 'Hours Watched', value: (completedEpisodes * 0.5).toFixed(1), icon: Clock },
  ];

  if (isLoadingData) {
    return (
      <div className="space-y-8 animate-pulse">
        <div className="mb-8">
          <div className="h-8 w-1/3 bg-white/10 rounded mb-2"></div>
          <div className="h-4 w-1/4 bg-white/10 rounded"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1,2,3].map(i => (
            <GlassCard key={i} className="flex items-center gap-4 h-24">
              <div className="w-12 h-12 rounded-xl bg-white/5"></div>
              <div className="flex-1">
                <div className="h-3 w-1/2 bg-white/5 rounded mb-2"></div>
                <div className="h-6 w-1/4 bg-white/10 rounded"></div>
              </div>
            </GlassCard>
          ))}
        </div>
        <div className="mt-12">
          <div className="h-8 w-48 bg-white/10 rounded mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <GlassCard key={i} className="p-0 h-[300px] flex flex-col overflow-hidden">
                <div className="h-40 bg-white/5 w-full"></div>
                <div className="p-5 flex-1 flex flex-col gap-3">
                  <div className="h-5 bg-white/10 w-3/4 rounded"></div>
                  <div className="h-2 bg-white/5 w-full rounded mt-auto"></div>
                  <div className="h-10 bg-white/10 w-full rounded mt-3"></div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3 mb-8">
        <Link
          to="/"
          className="inline-flex items-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
          title="Back to Home"
        >
          <ArrowLeft size={24} />
        </Link>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold mb-2">Welcome back, {user?.name}!</h1>
          <p className="text-gray-400">Ready to continue your trading journey?</p>
        </motion.div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <GlassCard className="flex items-center gap-4">
              <div className="p-4 rounded-xl bg-primary/10 text-primary">
                <stat.icon size={24} />
              </div>
              <div>
                <p className="text-gray-400 text-sm">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <PlayCircle className="text-primary" /> Continue Learning
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {publishedCourses.slice(0, 3).map((course, i) => {
            const courseProgress = progress.filter(p => p.userId === user?.id && p.courseId === course.id && p.isCompleted).length;
            const totalEps = course.episodes.length;
            const progressPercent = totalEps === 0 ? 0 : Math.round((courseProgress / totalEps) * 100);

            return (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
              >
                <GlassCard hoverEffect className="p-0 overflow-hidden flex flex-col h-full">
                  <div className="h-40 overflow-hidden relative">
                    <img src={course.thumbnail || undefined} alt={course.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-5 flex flex-col flex-1">
                    <h3 className="font-semibold mb-3">{course.title}</h3>
                    
                    <div className="mb-4 mt-auto">
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Progress</span>
                        <span>{progressPercent}%</span>
                      </div>
                      <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-primary"
                          initial={{ width: 0 }}
                          animate={{ width: `${progressPercent}%` }}
                          transition={{ duration: 1, ease: 'easeOut' }}
                        />
                      </div>
                    </div>

                    <Link to={`/dashboard/courses/${course.id}`}>
                      <Button className="w-full" size="sm">Resume Course</Button>
                    </Link>
                  </div>
                </GlassCard>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
