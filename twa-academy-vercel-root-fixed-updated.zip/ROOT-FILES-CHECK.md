# Root files check

For Vercel, these files must be visible on the first page of your GitHub repo or inside the folder you upload:

- package.json
- package-lock.json
- index.html
- vite.config.ts
- src/

Do not upload only this ZIP file into GitHub. Extract it first, then upload/push the extracted files.
