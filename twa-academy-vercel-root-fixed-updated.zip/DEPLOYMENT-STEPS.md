# TWA Academy - Vercel Deployment Steps

## 1. Local test
Run:

```bash
npm install
npm run build
```

## 2. Clerk key
Create a Clerk app, enable Google login, then copy your Publishable Key.
It starts with `pk_test_` or `pk_live_`.

## 3. Local environment
Create a `.env` file in the project root:

```env
VITE_CLERK_PUBLISHABLE_KEY=pk_test_your_real_key_here
```

Restart the dev server:

```bash
npm run dev
```

## 4. Vercel environment variable
In Vercel Project Settings, add:

Name:
```txt
VITE_CLERK_PUBLISHABLE_KEY
```

Value:
```txt
pk_test_your_real_key_here
```

Apply it to Production, Preview, and Development if Vercel asks.

## 5. Vercel build settings
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
Install Command: npm install

## 6. Deploy
Import the project from GitHub or upload this folder/ZIP to Vercel.
After adding the environment variable, redeploy.
