import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';
import { Button } from './ui/Button';

interface AdminUploadProps {
  onSave: (data: { title: string; description: string; file: File; url: string; duration: string }) => void;
  onCancel: () => void;
}

export function AdminUpload({ onSave, onCancel }: AdminUploadProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.size > 2 * 1024 * 1024 * 1024) {
        alert("File size exceeds 2GB limit.");
        return;
      }
      setFile(selectedFile);
      // For preview purposes
      const localUrl = URL.createObjectURL(selectedFile);
      setPreviewUrl(localUrl);
    }
  };

  const handleSave = () => {
    if (!title || !file) return;
    onSave({
      title,
      description,
      duration,
      file,
      url: previewUrl,
    });
  };

  const removeFile = () => {
    setFile(null);
    setPreviewUrl('');
  };

  return (
    <div className="bg-bg-sec border border-white/10 p-6 rounded-xl space-y-4 shadow-xl">
      <h2 className="font-semibold text-lg">Upload New Video Lesson</h2>
      
      <div className="space-y-4">
        <input 
          type="text" 
          placeholder="Video Title" 
          className="w-full bg-bg-main border border-white/10 rounded-lg px-4 py-2"
          value={title}
          onChange={e => setTitle(e.target.value)}
          required
        />
        
        <textarea 
          placeholder="Video Description" 
          className="w-full bg-bg-main border border-white/10 rounded-lg px-4 py-2 min-h-[100px]"
          value={description}
          onChange={e => setDescription(e.target.value)}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-text-secondary mb-2 block">Video File</label>
            {!file ? (
              <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-white/10 rounded-lg cursor-pointer bg-bg-main hover:bg-white/5 transition-colors">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-8 h-8 text-primary mb-2" />
                  <p className="text-sm text-gray-400 font-semibold mb-1">Click to upload or drag and drop</p>
                  <p className="text-xs text-text-secondary">MP4, WebM, or OGG (MAX. 2GB)</p>
                </div>
                <input 
                  type="file" 
                  accept="video/*"
                  onChange={handleVideoUpload}
                  className="hidden"
                />
              </label>
            ) : (
              <div className="relative overflow-hidden bg-black border border-white/10 rounded-lg h-32 flex justify-center items-center group">
                <video src={previewUrl || undefined} controlsList="nodownload" disablePictureInPicture className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" />
                <div className="absolute inset-x-0 bottom-0 p-2 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-between">
                  <span className="text-xs font-medium text-white truncate max-w-[70%]">{file.name}</span>
                  <span className="text-[10px] text-primary">{(file.size / (1024 * 1024)).toFixed(2)} MB</span>
                </div>
                <button 
                  onClick={removeFile}
                  className="absolute top-2 right-2 p-1.5 bg-black/50 text-white hover:text-red-500 hover:bg-black/80 transition-colors rounded-full backdrop-blur-md"
                >
                  <X size={16} />
                </button>
              </div>
            )}
          </div>
          
          <div>
            <label className="text-xs text-text-secondary mb-2 block">Duration</label>
            <input 
              type="text" 
              placeholder="e.g. 15 mins" 
              className="w-full bg-bg-main border border-white/10 rounded-lg px-4 py-3"
              value={duration}
              onChange={e => setDuration(e.target.value)}
            />
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-white/5 mt-4">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button 
            onClick={handleSave} 
            disabled={!title || !file}
            className="gap-2"
          >
            <Upload size={18} /> Upload Video
          </Button>
        </div>
      </div>
    </div>
  );
}
