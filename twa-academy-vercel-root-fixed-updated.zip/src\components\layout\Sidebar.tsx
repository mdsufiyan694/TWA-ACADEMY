import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import { TrendingUp, LayoutDashboard, PlaySquare, User as UserIcon, LogOut, Settings, Users, BookOpen, ArrowLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface SidebarProps {
  role: 'ADMIN' | 'STUDENT';
  onNavigate?: () => void;
}

export function Sidebar({ role, onNavigate }: SidebarProps) {
  const { user, logout } = useApp();
  const location = useLocation();

  const studentLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'My Courses', path: '/dashboard/courses', icon: PlaySquare },
    { name: 'Profile', path: '/dashboard/profile', icon: UserIcon },
  ];

  const adminLinks = [
    { name: 'Overview', path: '/admin', icon: LayoutDashboard },
    { name: 'Manage Courses', path: '/admin/courses', icon: BookOpen },
    { name: 'Students', path: '/admin/students', icon: Users },
    { name: 'Settings', path: '/admin/settings', icon: Settings },
  ];

  const links = role === 'ADMIN' ? adminLinks : studentLinks;

  return (
    <div className="w-full lg:w-64 flex-shrink-0 bg-bg-sec border-r border-white/10 p-4 min-h-[100dvh] flex flex-col sticky top-0">
      <div className="p-2">
        <Link to="/dashboard" className="flex items-center gap-2 group mb-8">
          <div className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white transition-colors">
             <TrendingUp size={20} />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-white leading-none">TWA ACADEMY</span>
          </div>
        </Link>

        {user && (
          <div className="flex items-center gap-3 mb-8 p-3 rounded-xl bg-white/5 border border-white/5">
            <div className="w-10 h-10 rounded-full bg-gradient-main flex items-center justify-center text-white font-bold text-sm">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex flex-col overflow-hidden">
              <span className="text-sm font-medium text-white truncate">{user.name}</span>
              <span className="text-xs text-primary">{role === 'ADMIN' ? 'Administrator' : 'Student'}</span>
            </div>
          </div>
        )}

        <nav className="flex flex-col gap-2">
          {links.map((link) => {
            const isActive = location.pathname === link.path || (link.path !== '/admin' && link.path !== '/dashboard' && location.pathname.startsWith(link.path));
            const Icon = link.icon;
            
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={onNavigate}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all ${
                  isActive 
                    ? 'bg-white/5 border border-white/10 text-primary font-semibold' 
                    : 'text-text-secondary hover:bg-white/5 font-semibold'
                }`}
              >
                <Icon size={20} />
                <span>{link.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-4 space-y-2">
        <button
          onClick={logout}
          className="flex items-center gap-3 px-4 py-3 w-full rounded-xl text-gray-400 hover:bg-red-500/10 hover:text-red-500 transition-colors"
        >
          <LogOut size={20} />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
}
