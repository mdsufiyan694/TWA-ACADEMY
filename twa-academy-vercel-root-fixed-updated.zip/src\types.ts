export type Role = 'ADMIN' | 'STUDENT';

export interface User {
  id: string;
  name: string;
  email: string;
  googleId?: string;
  photo?: string;
  role: Role;
  isBlocked: boolean;
  createdAt: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  thumbnail: string;
  tags: string[];
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
  episodes: Episode[];
}

export interface Episode {
  id: string;
  courseId: string;
  title: string;
  description: string;
  videoUrl: string;
  duration: string;
  order: number;
}

export interface Progress {
  id: string;
  userId: string;
  episodeId: string;
  courseId: string;
  isCompleted: boolean;
  watchedAt: string;
}
