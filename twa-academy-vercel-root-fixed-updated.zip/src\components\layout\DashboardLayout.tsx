import React, { useState } from 'react';
import { Outlet, Navigate, Link } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { useApp } from '../../context/AppContext';
import { Loader2, Menu, X, ArrowLeft } from 'lucide-react';

interface DashboardLayoutProps {
  requiredRole?: 'ADMIN' | 'STUDENT';
}

export function DashboardLayout({ requiredRole }: DashboardLayoutProps) {
  const { user, isLoadingAuth } = useApp();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  if (isLoadingAuth) {
    return <div className="app-container flex items-center justify-center bg-bg-main"><Loader2 className="animate-spin text-primary" size={32} /></div>;
  }

  if (!user) {
    if (requiredRole === 'ADMIN') {
      return <Navigate to="/admin/login" replace />;
    }
    return <Navigate to="/login" replace />;
  }

  if (requiredRole && user.role !== requiredRole) {
    if (user.role === 'ADMIN') {
      return <Navigate to="/admin" replace />;
    }
    if (user.role === 'STUDENT') {
      return <Navigate to="/dashboard" replace />;
    }
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="dashboard-layout w-full bg-bg-main relative flex-col lg:flex-row">
      <div className="lg:hidden flex items-center justify-between p-4 border-b border-white/10 bg-bg-sec z-50 relative">
        <div className="flex items-center gap-3">
          <Link
            to="/"
            className="inline-flex items-center p-1.5 -ml-1.5 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
          >
            <ArrowLeft size={24} />
          </Link>
          <div className="text-xl font-bold text-white tracking-tight">TWA ACADEMY</div>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-white p-2">
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      <div className={`${isMobileMenuOpen ? 'fixed inset-0 z-40 mt-[73px] bg-bg-sec overflow-y-auto block' : 'hidden'} lg:block lg:relative lg:mt-0`}>
         <Sidebar role={user.role} onNavigate={() => setIsMobileMenuOpen(false)} />
      </div>

      <main className="main-content overflow-y-auto overflow-x-hidden w-full p-4 sm:p-6 lg:p-8 flex-1">
        <Outlet />
      </main>
    </div>
  );
}
