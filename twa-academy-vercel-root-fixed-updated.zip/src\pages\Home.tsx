import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, BarChart2, ShieldAlert, TrendingUp, Presentation, Users, Play, CheckCircle } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { GlassCard } from '../components/ui/GlassCard';
import { useApp } from '../context/AppContext';
import { Hero } from '../components/Hero';

export function Home() {
  const { courses, user } = useApp();
  const publishedCourses = courses.filter(c => c.isPublished);

  const features = [
    { icon: TrendingUp, title: 'Price Action', desc: 'Master market structure and naked charts.' },
    { icon: BarChart2, title: 'Technical Analysis', desc: 'Advanced indicators and pattern recognition.' },
    { icon: Presentation, title: 'Options Trading', desc: 'Deep dive into derivatives and Greeks.' },
    { icon: ShieldAlert, title: 'Risk Management', desc: 'Protect capital and maximize returns.' },
  ];

  return (
    <div className="w-full">
      <Hero />

      {/* Features */}
      <section className="py-24 bg-bg-sec relative">
        <div className="container mx-auto px-6 max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What You'll Learn</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Comprehensive modules designed to take you from a beginner to an advanced trader.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <GlassCard hoverEffect className="h-full">
                  <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-6">
                    <f.icon size={24} />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{f.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{f.desc}</p>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 border-y border-white/5">
        <div className="container mx-auto px-6 max-w-7xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-gradient mb-2">10,000+</div>
              <div className="text-gray-400 font-medium">Active Students</div>
            </div>
            <div className="text-center md:border-x border-white/10">
              <div className="text-4xl md:text-5xl font-bold text-gradient mb-2">50+</div>
              <div className="text-gray-400 font-medium">Video Lessons</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-gradient-gold mb-2">100%</div>
              <div className="text-gray-400 font-medium">Free Access</div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses */}
      <section className="py-24">
        <div className="container mx-auto px-6 max-w-7xl">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Courses</h2>
              <p className="text-gray-400">Start your journey with our top-rated content.</p>
            </div>
            <Link to="/courses">
              <Button variant="ghost" className="gap-2">View All Courses <ArrowRight size={16} /></Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {publishedCourses.slice(0,3).map((course, i) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <GlassCard hoverEffect className="p-0 overflow-hidden group flex flex-col h-full">
                  <div className="h-48 overflow-hidden relative">
                    <img src={course.thumbnail || undefined} alt={course.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute top-4 left-4 bg-primary text-black text-xs font-bold px-3 py-1 rounded-full">
                      {course.category}
                    </div>
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">{course.title}</h3>
                    <p className="text-gray-400 text-sm mb-6 line-clamp-2">{course.description}</p>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="text-sm text-gray-500 flex items-center gap-1">
                        <Play size={14} /> {course.episodes.length} Episodes
                      </div>
                      <Link to={user ? `/dashboard/courses/${course.id}` : "/login"}>
                        <Button variant="outline" size="sm">Learn Now</Button>
                      </Link>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
