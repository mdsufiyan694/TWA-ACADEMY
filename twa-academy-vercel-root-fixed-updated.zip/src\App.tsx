/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { AppRoutes } from './routes/AppRoutes';

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <div className="w-full min-h-[100dvh] text-white bg-bg-main selection:bg-primary/30 selection:text-white font-sans overflow-x-hidden m-0 p-0">
          <AppRoutes />
        </div>
      </AppProvider>
    </BrowserRouter>
  );
}

