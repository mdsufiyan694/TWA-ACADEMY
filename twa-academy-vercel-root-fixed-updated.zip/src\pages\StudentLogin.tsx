import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSignIn, useUser } from '@clerk/clerk-react';
import { motion } from 'motion/react';
import { TrendingUp, ArrowLeft, Loader2 } from 'lucide-react';
import { GlassCard } from '../components/ui/GlassCard';

function GoogleIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 48 48" aria-hidden="true">
      <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303C33.652 32.657 29.223 36 24 36c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z" />
      <path fill="#FF3D00" d="m6.306 14.691 6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 16.318 4 9.656 8.337 6.306 14.691z" />
      <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238C29.211 35.091 26.715 36 24 36c-5.202 0-9.619-3.317-11.285-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z" />
      <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z" />
    </svg>
  );
}

export function StudentLogin() {
  const navigate = useNavigate();
  const { signIn, isLoaded } = useSignIn();
  const { isSignedIn } = useUser();
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (isSignedIn) {
      navigate('/dashboard', { replace: true });
    }
  }, [isSignedIn, navigate]);

  const handleGoogleLogin = async () => {
    if (!isLoaded || !signIn) return;

    setIsLoading(true);
    setErrorMsg('');

    try {
      await signIn.authenticateWithRedirect({
        strategy: 'oauth_google',
        redirectUrl: '/sso-callback',
        redirectUrlComplete: '/dashboard',
        continueSignIn: true,
        continueSignUp: true,
      });
    } catch (error: any) {
      console.error(error);
      setErrorMsg(error?.errors?.[0]?.message || error?.message || 'Google login failed. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <div className="page-wrapper flex items-center justify-center relative overflow-hidden bg-[#050816] p-4 text-white min-h-[100dvh]">
      <div className="absolute top-1/4 -left-1/4 w-1/2 h-1/2 bg-[#00E676]/10 blur-[120px] rounded-full" />
      <div className="absolute bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-[#F5C542]/10 blur-[120px] rounded-full" />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full relative z-10 flex justify-center"
      >
        <div className="w-full max-w-[675px]">
          <GlassCard className="px-8 py-12 md:px-16 md:py-16 border-[#00E676]/20 bg-[rgba(255,255,255,0.06)] shadow-[0_0_30px_rgba(0,230,118,0.1)] relative rounded-[18px]">
            <button 
              onClick={() => navigate('/')}
              className="absolute left-8 top-10 p-2 -ml-2 rounded-full hover:bg-white/10 text-[#B0B8C4] hover:text-white transition-colors"
              aria-label="Go back to home"
            >
              <ArrowLeft size={28} />
            </button>

            <div className="flex justify-center mb-10">
              <div className="h-24 w-24 rounded-3xl bg-[#00E676]/10 text-[#00E676] flex items-center justify-center shadow-[0_0_34px_rgba(0,230,118,0.22)]">
                <TrendingUp size={46} strokeWidth={3} />
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-center mb-5 text-white">TWA Academy</h1>
            <p className="text-[#D7DEF0] mb-14 text-center text-xl md:text-2xl font-medium">Trade made simple.</p>
            
            <p className="text-[#D7DEF0] mb-12 text-center text-xl md:text-2xl leading-relaxed max-w-[540px] mx-auto">
              Login securely with Google to access your free trading course.
            </p>

            {errorMsg && (
              <div className="mb-8 p-4 bg-red-500/10 border border-red-500/50 rounded-xl text-red-400 text-base text-center">
                {errorMsg}
              </div>
            )}

            <button 
              className="w-full flex items-center justify-center gap-5 bg-white text-black hover:bg-white/95 h-[72px] rounded-xl text-xl md:text-2xl font-bold mb-10 border-none shadow-[0_0_30px_rgba(0,230,118,0.10)] transition-all disabled:opacity-70 disabled:cursor-not-allowed"
              onClick={handleGoogleLogin}
              disabled={isLoading || !isLoaded}
              type="button"
            >
              {isLoading ? <Loader2 size={28} className="animate-spin" /> : <GoogleIcon />}
              Continue with Google
            </button>
            
            <div className="flex justify-center flex-col items-center gap-4 border-t border-white/10 pt-10 mt-6">
              <span className="text-[#727B96] text-lg md:text-xl text-center">Are you an administrator?</span>
              <button 
                onClick={() => navigate('/admin/login')}
                className="text-[#D7DEF0] hover:text-[#00E676] text-lg md:text-xl font-bold transition-colors"
              >
                Access Admin Portal
              </button>
            </div>
          </GlassCard>
        </div>
      </motion.div>
    </div>
  );
}
