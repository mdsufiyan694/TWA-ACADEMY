import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Shield, Eye, EyeOff, ArrowLeft } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { GlassCard } from '../components/ui/GlassCard';
import { useApp } from '../context/AppContext';

export function AdminLogin() {
  const { setLocalAdminSession } = useApp();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleLogin = async () => {
    if (!email || !password) return;
    
    setIsLoading(true);
    setErrorMsg('');
    
    // Slight artificial delay for UX and to prevent brute-force feeling
    await new Promise(r => setTimeout(r, 800));

    if (email === 'twaacademy@gmail.com' && password === 'TWA@0102') {
      setLocalAdminSession(email);
      // Ensure local storage syncs before routing
      window.dispatchEvent(new Event('storage'));
      navigate('/admin');
    } else {
      setErrorMsg('Invalid admin ID or password.');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="page-wrapper flex items-center justify-center relative overflow-hidden bg-[#050816] p-4 text-white">
      {/* Dark premium glow for admin */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-[#00E676]/5 blur-[200px] rounded-full" />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full relative z-10 flex justify-center"
      >
        <div className="w-full max-w-[450px]">
          <GlassCard className="p-8 md:p-10 border-[#00E676]/30 bg-[rgba(255,255,255,0.06)] shadow-[0_0_40px_rgba(0,230,118,0.15)] relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00E676] to-transparent opacity-50" />
            
            <button 
              onClick={() => navigate('/')}
              className="absolute left-6 top-8 p-2 -ml-2 rounded-full hover:bg-white/10 text-[#B0B8C4] hover:text-white transition-colors z-10"
              aria-label="Go back to home"
            >
              <ArrowLeft size={20} />
            </button>

            <div className="flex justify-center mb-6">
              <div className="h-16 w-16 rounded-2xl bg-[#00E676]/20 text-[#00E676] flex items-center justify-center shadow-[0_0_20px_rgba(0,230,118,0.2)] relative z-10">
                <Shield size={32} />
              </div>
            </div>
            
            <h1 className="text-3xl font-bold text-center mb-2 text-white">Admin Portal</h1>
            <p className="text-[#00E676] mb-8 text-center text-sm uppercase tracking-widest font-semibold flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00E676] animate-pulse" />
              Restricted Access
            </p>

            {errorMsg && (
              <div className="mb-6 p-3 bg-red-500/10 border border-red-500/50 rounded-lg text-red-500 text-sm text-center">
                {errorMsg}
              </div>
            )}

            <div className="space-y-6">
              <div>
                <div className="relative">
                  <input 
                    type="email" 
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-[#050816]/50 border border-white/20 rounded-lg px-4 py-3 pb-2 pt-5 focus:border-[#00E676] focus:ring-1 focus:ring-[#00E676] outline-none transition-all peer text-white placeholder-transparent"
                    placeholder="Email"
                    onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  />
                  <label className="absolute text-sm text-[#B0B8C4] px-1 left-3 top-3.5 transition-all peer-focus:top-1 peer-focus:text-xs peer-focus:text-[#00E676] peer-focus:bg-[#050816] peer-[:not(:placeholder-shown)]:top-1 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:bg-[#050816] pointer-events-none rounded">
                    Admin Email
                  </label>
                </div>
              </div>

              <div>
                <div className="relative">
                  <input 
                    type={showPassword ? "text" : "password"} 
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full bg-[#050816]/50 border border-white/20 rounded-lg px-4 py-3 pb-2 pt-5 focus:border-[#00E676] focus:ring-1 focus:ring-[#00E676] outline-none transition-all peer text-white placeholder-transparent pr-10"
                    placeholder="Password"
                    onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                  />
                  <label className="absolute text-sm text-[#B0B8C4] px-1 left-3 top-3.5 transition-all peer-focus:top-1 peer-focus:text-xs peer-focus:text-[#00E676] peer-focus:bg-[#050816] peer-[:not(:placeholder-shown)]:top-1 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:bg-[#050816] pointer-events-none rounded">
                    Password
                  </label>
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#B0B8C4] hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </div>
              </div>
              
              <div className="pt-2">
                <Button 
                  onClick={handleLogin} 
                  isLoading={isLoading} 
                  disabled={!email || !password}
                  className="w-full h-12 text-base font-semibold bg-[#00E676] hover:bg-[#00E676]/90 text-black border-none"
                >
                  Verify Identity
                </Button>
              </div>
            </div>
          </GlassCard>
        </div>
      </motion.div>
    </div>
  );
}
