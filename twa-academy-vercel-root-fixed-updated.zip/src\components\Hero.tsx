import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, Play } from 'lucide-react';
import { Button } from './ui/Button';

export function Hero() {
  return (
    <section className="relative overflow-hidden min-h-[90vh] flex items-center pt-20">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(0,230,118,0.18),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(245,197,66,0.14),transparent_35%)]" />

      {/* Floating Trading Cards background effect */}
      <div className="absolute left-10 top-1/4 opacity-20 pointer-events-none hidden xl:block blur-[1px]">
        <motion.div animate={{y: [0, -20, 0]}} transition={{duration: 6, repeat: Infinity, ease: "easeInOut"}} className="bg-bg-sec border border-white/10 p-4 rounded-xl flex flex-col gap-2 shadow-2xl">
          <span className="text-primary font-bold text-sm">NIFTY 50</span>
          <span className="text-white text-lg">22,419.55</span>
          <span className="text-primary text-xs">+0.82% ▲</span>
        </motion.div>
      </div>
      
      <div className="absolute right-1/4 bottom-1/4 opacity-20 pointer-events-none hidden xl:block blur-[1px]">
        <motion.div animate={{y: [0, 20, 0]}} transition={{duration: 7, repeat: Infinity, ease: "easeInOut"}} className="bg-bg-sec border border-white/10 p-4 rounded-xl flex flex-col gap-2 shadow-2xl">
          <span className="text-primary font-bold text-sm">BANKNIFTY</span>
          <span className="text-white text-lg">47,845.20</span>
          <span className="text-primary text-xs">+1.15% ▲</span>
        </motion.div>
      </div>

      {/* Candlestick decoration bg - purely css/svg */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 h-full opacity-30 pointer-events-none hidden lg:block">
        <div className="absolute inset-0 bg-gradient-to-r from-bg-main via-transparent to-transparent z-10"></div>
        <svg width="100%" height="100%" viewBox="0 0 400 400" preserveAspectRatio="none">
          <motion.rect initial={{height:0}} animate={{height:80}} transition={{delay:0.2, duration:1}} x="50" y="200" width="20" fill="var(--color-primary-dark)" rx="4"/>
          <rect x="59" y="150" width="2" height="150" fill="var(--color-primary-dark)" />
          
          <motion.rect initial={{height:0}} animate={{height:120}} transition={{delay:0.4, duration:1}} x="110" y="150" width="20" fill="var(--color-primary)" rx="4"/>
          <rect x="119" y="90" width="2" height="200" fill="var(--color-primary)" />
          
          <motion.rect initial={{height:0}} animate={{height:60}} transition={{delay:0.6, duration:0.5}} x="170" y="270" width="20" fill="var(--color-danger)" rx="4"/>
          <rect x="179" y="250" width="2" height="100" fill="var(--color-danger)" />
          
          <motion.rect initial={{height:0}} animate={{height:160}} transition={{delay:0.8, duration:1.5}} x="230" y="50" width="20" fill="var(--color-primary)" rx="4"/>
          <rect x="239" y="10" width="2" height="250" fill="var(--color-primary)" />
          
          <motion.rect initial={{height:0}} animate={{height:90}} transition={{delay:1.0, duration:1.0}} x="290" y="160" width="20" fill="var(--color-primary)" rx="4"/>
          <rect x="299" y="120" width="2" height="150" fill="var(--color-primary)" />
        </svg>
      </div>

      <div className="container mx-auto px-6 max-w-7xl relative z-20">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-primary text-sm font-semibold mb-8 backdrop-blur-md shadow-lg"
          >
            <div className="w-6 h-6 bg-gradient-to-tr from-[#00E676] to-[#00C853] rounded flex items-center justify-center font-bold text-black text-[10px] italic">TWA</div>
            Premium Trading Academy
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight mb-6 leading-tight text-white"
          >
            Trade Make <span className="text-gradient">Simple</span> with Pro Education
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-text-secondary mb-10 max-w-2xl leading-relaxed"
          >
            Master Price Action, Risk Management, and Options Trading. Join our premium academy designed to take you from beginner to consistently profitable.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap items-center gap-4"
          >
            <Link to="/auth/signin">
              <Button size="lg" className="gap-2 px-8 font-extrabold hover:shadow-primary/50 transition-all duration-300">
                Enroll Now <ArrowRight size={20} />
              </Button>
            </Link>
            <Link to="/courses">
              <Button size="lg" variant="outline" className="gap-2 px-8 bg-white/5 backdrop-blur-md border-white/20 hover:border-white/40">
                <Play size={20} /> Watch Free Demo
              </Button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
