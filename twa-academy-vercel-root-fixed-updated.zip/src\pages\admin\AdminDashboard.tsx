import React from 'react';
import { motion } from 'motion/react';
import { Users, BookOpen, Play, TrendingUp, ArrowRight, ArrowLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GlassCard } from '../../components/ui/GlassCard';
import { Link } from 'react-router-dom';

export function AdminDashboard() {
  const { allUsers, courses, isLoadingData } = useApp();
  
  const stats = [
    { label: 'Total Students', value: allUsers.filter(u => u.role === 'STUDENT').length, icon: Users, color: 'text-primary', link: '/admin/students' },
    { label: 'Total Courses', value: courses.length, icon: BookOpen, color: 'text-secondary', link: '/admin/courses' },
    { label: 'Published Courses', value: courses.filter(c => c.isPublished).length, icon: TrendingUp, color: 'text-green-500', link: '/admin/courses' },
    { label: 'Total Videos', value: courses.reduce((acc, curr) => acc + curr.episodes.length, 0), icon: Play, color: 'text-blue-500' },
  ];

  if (isLoadingData) {
    return (
      <div className="space-y-8 animate-pulse">
        <div className="h-10 w-1/4 bg-white/10 rounded mb-8"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {[1,2,3,4].map(i => (
            <GlassCard key={i} className="flex items-center gap-4 h-24">
              <div className="w-12 h-12 rounded-xl bg-white/5"></div>
              <div className="flex-1">
                <div className="h-3 w-1/2 bg-white/5 rounded mb-2"></div>
                <div className="h-6 w-1/4 bg-white/10 rounded"></div>
              </div>
            </GlassCard>
          ))}
        </div>
        <div className="grid lg:grid-cols-2 gap-8">
          <GlassCard className="h-96">
             <div className="h-6 w-1/3 bg-white/10 rounded mb-6"></div>
             <div className="space-y-4">
               {[1,2,3,4].map(i => <div key={i} className="h-12 w-full bg-white/5 rounded"></div>)}
             </div>
          </GlassCard>
          <GlassCard className="h-96">
             <div className="h-6 w-1/3 bg-white/10 rounded mb-6"></div>
             <div className="space-y-4">
               {[1,2,3,4].map(i => <div key={i} className="h-12 w-full bg-white/5 rounded"></div>)}
             </div>
          </GlassCard>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3">
        <Link
          to="/"
          className="inline-flex items-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
          title="Back to Home"
        >
          <ArrowLeft size={24} />
        </Link>
        <h1 className="text-3xl font-bold">Dashboard Overview</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            {stat.link ? (
              <Link to={stat.link}>
                <GlassCard className="flex items-center gap-4 hover:border-white/20 transition-colors">
                  <div className={`p-4 rounded-xl bg-white/5 ${stat.color}`}>
                    <stat.icon size={24} />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">{stat.label}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                </GlassCard>
              </Link>
            ) : (
              <GlassCard className="flex items-center gap-4">
                <div className={`p-4 rounded-xl bg-white/5 ${stat.color}`}>
                  <stat.icon size={24} />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              </GlassCard>
            )}
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <GlassCard>
          <div className="flex justify-between items-center mb-6">
            <Link to="/admin/students" className="group flex items-center gap-2 hover:text-primary transition-colors">
              <h2 className="text-xl font-semibold">Recent Students</h2>
            </Link>
          </div>
          <div className="space-y-4">
            {allUsers.filter(u => u.role === 'STUDENT').slice(0,5).map(student => (
              <div key={student.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-white/5 border border-transparent hover:border-white/5 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-main flex items-center justify-center text-white font-bold">
                    {student.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium">{student.name}</p>
                    <p className="text-xs text-gray-400">{student.email}</p>
                  </div>
                </div>
                <div className="text-xs text-gray-500">
                  {new Date(student.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard>
          <div className="flex justify-between items-center mb-6">
            <Link to="/admin/courses" className="group flex items-center gap-2 hover:text-primary transition-colors">
              <h2 className="text-xl font-semibold">Recent Courses</h2>
            </Link>
          </div>
          <div className="space-y-4">
            {courses.slice(0,5).map(course => (
              <div key={course.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 border border-transparent hover:border-white/5 transition-colors">
                <img src={course.thumbnail || undefined} alt="" className="w-16 h-12 object-cover rounded-md" />
                <div className="flex-1">
                  <p className="font-medium line-clamp-1">{course.title}</p>
                  <p className="text-xs text-gray-400">{course.episodes.length} Episodes</p>
                </div>
                <div className={`px-2 py-1 rounded text-xs ${course.isPublished ? 'bg-green-500/20 text-green-500' : 'bg-yellow-500/20 text-yellow-500'}`}>
                  {course.isPublished ? 'Published' : 'Draft'}
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
