import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Plus, Edit, Trash2, Video, ListVideo, ArrowLeft } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Link, useNavigate } from 'react-router-dom';

export function AdminCourses() {
  const { courses, deleteCourse, addCourse } = useApp();
  const navigate = useNavigate();
  const [isAdding, setIsAdding] = useState(false);
  
  // Basic add form state
  const [newCourse, setNewCourse] = useState({
    title: '', description: '', category: 'Price Action', thumbnail: '', isPublished: false
  });

  const handleSave = () => {
    addCourse(newCourse);
    setIsAdding(false);
    setNewCourse({ title: '', description: '', category: 'Price Action', thumbnail: '', isPublished: false });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-bg-sec p-6 rounded-2xl border border-white/10 sticky top-0 z-10 gap-4">
        <div className="flex items-center gap-3">
          <Link
            to="/admin"
            className="inline-flex items-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
            title="Back to Dashboard"
          >
            <ArrowLeft size={24} />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">Manage Courses</h1>
            <p className="text-gray-400 text-sm">Create and edit trading courses</p>
          </div>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)}>
          <Plus size={18} className="mr-2" /> Add Course
        </Button>
      </div>

      {isAdding && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
          <GlassCard className="border-primary/30">
             <h2 className="text-xl font-semibold mb-4">Add New Course</h2>
             <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Course Title" 
                  className="w-full bg-bg-main border border-white/10 rounded-lg px-4 py-2"
                  value={newCourse.title}
                  onChange={e => setNewCourse({...newCourse, title: e.target.value})}
                />
                <textarea 
                  placeholder="Course Description" 
                  className="w-full bg-bg-main border border-white/10 rounded-lg px-4 py-2 min-h-[100px]"
                  value={newCourse.description}
                  onChange={e => setNewCourse({...newCourse, description: e.target.value})}
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <select 
                    className="w-full bg-bg-main border border-white/10 rounded-lg px-4 py-2 text-white"
                    value={newCourse.category}
                    onChange={e => setNewCourse({...newCourse, category: e.target.value})}
                  >
                    <option>Price Action</option>
                    <option>Technical Analysis</option>
                    <option>Options Trading</option>
                    <option>Risk Management</option>
                  </select>
                  <input 
                    type="text" 
                    placeholder="Thumbnail Image URL" 
                    className="w-full bg-bg-main border border-white/10 rounded-lg px-4 py-2"
                    value={newCourse.thumbnail}
                    onChange={e => setNewCourse({...newCourse, thumbnail: e.target.value})}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="checkbox" 
                    checked={newCourse.isPublished}
                    onChange={e => setNewCourse({...newCourse, isPublished: e.target.checked})}
                  />
                  <label>Publish immediately</label>
                </div>
                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="ghost" onClick={() => setIsAdding(false)}>Cancel</Button>
                  <Button onClick={handleSave}>Save Course</Button>
                </div>
             </div>
          </GlassCard>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <GlassCard key={course.id} className="p-0 overflow-hidden flex flex-col hover:border-white/20 transition-colors">
            <div className="h-40 overflow-hidden relative">
              <img src={course.thumbnail || 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'} alt="" className="w-full h-full object-cover" />
              <div className={`absolute top-4 right-4 text-xs font-bold px-2 py-1 rounded ${course.isPublished ? 'bg-green-500 text-black' : 'bg-yellow-500 text-black'}`}>
                {course.isPublished ? 'Published' : 'Draft'}
              </div>
            </div>
            <div className="p-5 flex flex-col flex-1">
              <h3 className="font-semibold text-lg mb-1">{course.title}</h3>
              <p className="text-gray-400 text-xs mb-4">{course.category}</p>
              
              <div className="flex items-center justify-between text-sm text-gray-400 mb-6 border-y border-white/5 py-3">
                <span className="flex items-center gap-1"><ListVideo size={14}/> {course.episodes.length} Episodes</span>
              </div>

              <div className="mt-auto flex items-center justify-between">
                <Button variant="outline" size="sm" onClick={() => navigate(`/admin/courses/${course.id}/episodes`)}>
                  Manage Videos
                </Button>
                <div className="flex gap-2">
                   <button className="p-2 text-gray-400 hover:text-white rounded bg-white/5"><Edit size={16}/></button>
                   <button 
                     className="p-2 text-red-500 hover:text-red-400 rounded bg-red-500/10"
                     onClick={() => deleteCourse(course.id)}
                   ><Trash2 size={16}/></button>
                </div>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
