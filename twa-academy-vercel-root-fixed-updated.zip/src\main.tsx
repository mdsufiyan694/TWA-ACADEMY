import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { ClerkProvider } from '@clerk/clerk-react';
import App from './App.tsx';
import './index.css';

const clerkPublishableKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY as string | undefined;

function MissingClerkKey() {
  return (
    <div className="min-h-screen bg-[#050816] text-white flex items-center justify-center px-6 text-center">
      <div className="max-w-xl rounded-2xl border border-[#00E676]/30 bg-white/[0.04] p-8 shadow-[0_0_40px_rgba(0,230,118,0.12)]">
        <h1 className="text-2xl font-bold mb-4">Missing Clerk Publishable Key</h1>
        <p className="text-[#B0B8C4] mb-4">
          Add your Clerk Publishable Key in the project root <code className="text-white">.env</code> file.
        </p>
        <pre className="bg-black/40 rounded-xl p-4 text-left overflow-x-auto text-sm text-[#00E676]">
{`VITE_CLERK_PUBLISHABLE_KEY=pk_test_your_real_key_here`}
        </pre>
        <p className="text-[#B0B8C4] mt-4 text-sm">
          After saving the file, stop the server and run <code className="text-white">npm run dev</code> again.
        </p>
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    {clerkPublishableKey ? (
      <ClerkProvider publishableKey={clerkPublishableKey} afterSignOutUrl="/login">
        <App />
      </ClerkProvider>
    ) : (
      <MissingClerkKey />
    )}
  </StrictMode>,
);
