import React from 'react';
import { ArrowLeft, PlayCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';

export function MyCourses() {
  const { user, courses, progress } = useApp();
  const publishedCourses = courses.filter(c => c.isPublished);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 bg-bg-sec p-6 rounded-2xl border border-white/10 sticky top-0 z-10">
        <Link
          to="/dashboard"
          className="inline-flex items-center p-2 rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-colors"
          title="Back to Dashboard"
        >
          <ArrowLeft size={24} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold">My Courses</h1>
          <p className="text-gray-400 text-sm">Continue where you left off</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {publishedCourses.map((course, i) => {
          const courseProgress = progress.filter(p => p.userId === user?.id && p.courseId === course.id && p.isCompleted).length;
          const totalEps = course.episodes.length;
          const progressPercent = totalEps === 0 ? 0 : Math.round((courseProgress / totalEps) * 100);

          return (
            <GlassCard hoverEffect key={course.id} className="p-0 overflow-hidden flex flex-col h-full">
              <div className="h-40 overflow-hidden relative">
                <img src={course.thumbnail || undefined} alt={course.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-5 flex flex-col flex-1">
                <h3 className="font-semibold mb-3">{course.title}</h3>
                
                <div className="mb-4 mt-auto">
                  <div className="flex justify-between text-xs text-gray-400 mb-1">
                    <span>Progress</span>
                    <span>{progressPercent}%</span>
                  </div>
                  <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>

                <Link to={`/dashboard/courses/${course.id}`}>
                  <Button className="w-full" size="sm">Resume Course</Button>
                </Link>
              </div>
            </GlassCard>
          );
        })}
        {publishedCourses.length === 0 && (
          <div className="col-span-full p-8 text-center text-gray-400 border border-white/10 rounded-2xl border-dashed">
            No courses available yet.
          </div>
        )}
      </div>
    </div>
  );
}
